package com.sagarrathod.bibliophile.tasks;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.pdf.PdfRenderer;
import android.os.AsyncTask;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.sagarrathod.bibliophile.beans.Book;
import com.sagarrathod.bibliophile.database.BibliophileProvider;
import com.sagarrathod.bibliophile.database.FileColumns;
import com.sagarrathod.bibliophile.utils.Constants;
import com.sagarrathod.bibliophile.utils.ContentResolverUtils;
import com.sagarrathod.bibliophile.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Sagar Rathod on 07-Jan-2017.
 */

public class CacheImageTasks extends AsyncTask<Void,Void, Void>{

    private static final String TAG = "CacheImageTasks";

    private Context mContext;

    public CacheImageTasks(Context context){
        this.mContext = context;
    }

    @Override
    protected Void doInBackground(Void... params) {

        ContentResolverUtils contentResolverUtils = new ContentResolverUtils(mContext);
        File dir = mContext.getDir(Constants.THUMBNAIL_DIRECTORY, Context.MODE_PRIVATE);

        List<Book> bookList = contentResolverUtils.findNullThumbnailsBooks();
        Map<Integer,ContentValues> bookMap = new HashMap<Integer, ContentValues>();
        for(Book localBook: bookList){

            String fileName = localBook.getTitle();
            try {

                File thumbnailFile = new File(dir, Utils.createBookThumbnailNameFromFile(fileName));

                FileOutputStream outputFile = new FileOutputStream(thumbnailFile);

                URI fileUri = new URI(localBook.getFileUri());

                File inputFile = new File(fileUri);

                if(inputFile.canRead() && inputFile.exists()){
                    Log.d(TAG, "File is Readable:" + fileUri.toString());
                }

                ParcelFileDescriptor fileDescriptor = ParcelFileDescriptor.open(inputFile,
                        ParcelFileDescriptor.MODE_READ_ONLY);

                Log.d(TAG, "Is error:" + fileDescriptor.canDetectErrors());

                PdfRenderer pdfRenderer;
                try{

                    pdfRenderer = new PdfRenderer(fileDescriptor);

                }catch (IOException e){
                    e.printStackTrace();
                    fileDescriptor.close();
                    outputFile.close();
                    Log.e(TAG, "Unable to open file:" + fileUri.toString());

                    continue;
                }

                PdfRenderer.Page firstPage = pdfRenderer.openPage(0);

                Bitmap targetBitmap = Bitmap.createBitmap(firstPage.getWidth(), firstPage.getHeight(),
                        Bitmap.Config.ARGB_4444);

                firstPage.render(targetBitmap, null , null,
                        PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

                boolean isSuccessfulCompression =
                        targetBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputFile);

                outputFile.flush();
                outputFile.close();

                targetBitmap.recycle();

                firstPage.close();
                pdfRenderer.close();

                ContentValues contentValues = new ContentValues();
                contentValues.put(FileColumns.FILE_THUMBNAIL, thumbnailFile.toURI().toString());

                bookMap.put(localBook.getBookId(), contentValues);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (URISyntaxException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        boolean result = contentResolverUtils.bulkUpdate(bookMap);
        Log.d("CacheImageTasks:" ,"Result:" + result);

        return null;
    }
}
