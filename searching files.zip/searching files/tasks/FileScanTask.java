package com.sagarrathod.bibliophile.tasks;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;

import com.sagarrathod.bibliophile.database.BibliophileProvider;
import com.sagarrathod.bibliophile.database.FileColumns;
import com.sagarrathod.filemanager.DirectoryScanner;
import com.sagarrathod.filemanager.FileExtension;
import com.sagarrathod.filemanager.FileManagerException;

import android.net.Uri;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by samsung on 02-Jan-2017.
 */

public class FileScanTask extends AsyncTask<Void,Void,List<Uri>>{

    private static final String TAG = "FileScanTask";
    private Context mContext;

    File directories[];

    public FileScanTask(Context contexts,File[] dir) {
        if(dir == null || contexts == null)
            throw  new NullPointerException("FileScanTask Arguments cannot be null.");
        this.directories = dir;
        this.mContext = contexts;
    }

    @Override
    protected List<Uri> doInBackground(Void... params) {

        List<Uri> uriList = new ArrayList<Uri>();
        try {
            for (File dir : directories) {
                DirectoryScanner directoryScanner = new DirectoryScanner(dir);
                List<String> uris = directoryScanner.searchFiles(FileExtension.PDF);

                if(uris != null){
                    for(String stringUri: uris){
                        uriList.add(Uri.parse(stringUri));
                    }
                }
            }
            int uriSize = uriList.size();
            ContentValues contentValues[] = new ContentValues[uriSize];

            for(int i = 0; i < uriSize; i++){
                Uri uri = uriList.get(i);
                contentValues[i] = new ContentValues();
                contentValues[i].put(FileColumns.FILE_NAME, uri.getLastPathSegment());
                contentValues[i].put(FileColumns.FILE_URI, uri.toString());
                contentValues[i].putNull(FileColumns.FILE_THUMBNAIL);
            }

            ContentResolver contentResolver = mContext.getContentResolver();

            // make the table empty
            String whereClause = FileColumns.FILE_NAME + " IS NOT NULL";
            int rows = contentResolver.delete(BibliophileProvider.FILES.FILES, whereClause, null);
            Log.d(TAG, "Rows Deleted:" + rows);

            // Then insert new rows
            rows = contentResolver.bulkInsert(BibliophileProvider.FILES.FILES, contentValues);
            Log.d(TAG, "Rows inserted:" + rows);

        }catch (FileManagerException fe){
            Log.d(TAG, fe.getMessage());
        }

        return  uriList;
    }

    @Override
    protected void onPostExecute(List<Uri> uris) {
        super.onPostExecute(uris);
        Log.d(TAG, uris.toString());
    }
}
