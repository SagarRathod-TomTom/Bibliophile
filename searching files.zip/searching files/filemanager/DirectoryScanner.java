package com.sagarrathod.filemanager;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Sagar Rathod
 */

public class DirectoryScanner {

    FileExtension fileExtension;
    File rootDir;
    List<String> uriList = new ArrayList<String>();

    public DirectoryScanner(File dir) throws FileManagerException {
        if (dir == null)
            throw new NullPointerException("Directory cannot be null.");

        if(!dir.isDirectory())
            throw new FileManagerException("File Argument can only be a directory.");

        this.rootDir = dir;
    }

    public List<String> searchFiles(FileExtension fileExtension){

        if(fileExtension == null)
            throw new NullPointerException("File extension cannot be null.");

        this.fileExtension = fileExtension;
        applyFilter(rootDir);
        return uriList;
    }

    private void applyFilter(File dir) {

        File[] list = dir.listFiles();

        if(list != null){
            for (File file : list) {
                if (file.isDirectory()) {
                    applyFilter(file);
                }
                else {
                        String fileName = file.getName();
                        if(fileName.endsWith(fileExtension.getExtension()))
                        uriList.add(file.toURI().toString());
                }
            }
        }
    }

}
