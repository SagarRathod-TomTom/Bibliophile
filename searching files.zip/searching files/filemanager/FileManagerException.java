package com.sagarrathod.filemanager;

/**
 * Created by samsung on 31-Dec-2016.
 */

public class FileManagerException extends Exception {

    private String message;

    public FileManagerException(String message){
        this.message = message;
    }

    public FileManagerException(Exception e){
        this.message = e.getMessage();
    }


    @Override
    public String toString(){
        return "FileManagerException[ " + message + "]";
    }
}
