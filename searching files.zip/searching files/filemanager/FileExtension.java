package com.sagarrathod.filemanager;

/**
 * Created by samsung on 31-Dec-2016.
 */

public enum FileExtension{

    PDF(".pdf"), TEXT(".txt"), EPUB(".epub");

    private String extension;

    private FileExtension(String extension){
        this.extension = extension;
    }

    public boolean matches(String ext){
        return extension.equalsIgnoreCase(ext);
    }

    public String getExtension(){
        return  extension;
    }
}
